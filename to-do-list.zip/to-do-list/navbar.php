<nav class="navbar navbar-expand-lg shadow" style="background: linear-gradient(to right, #4a90e2, #357abd);">
    <div class="container">
        <!-- Brand -->
        <a class="navbar-brand d-flex align-items-center" href="/to-do-list/index.php">
            <img src="/to-do-list/img/LOGO.png" alt="Logo" width="70" height="70"
                class="d-inline-block align-text-top me-2">
            <span style="background: linear-gradient(to right, #ffffff, #cde8ff);
                         -webkit-background-clip: text;
                         -webkit-text-fill-color: transparent;
                         font-weight: bold;
                         font-size: 1.5rem;">
                TICKLE TASK
            </span>
        </a>

        <!-- Toggle Button -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar Links -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <!-- About -->
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'about.php' ? 'active' : ''; ?>"
                        href="/to-do-list/about.php">
                        <i class="fas fa-info-circle"></i> About
                    </a>
                </li>

                <!-- Task Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle text-white <?php echo in_array(basename($_SERVER['PHP_SELF']), ['index.php', 'completed.php']) ? 'active' : ''; ?>"
                        href="#" id="taskDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-tasks"></i> Tasks
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="taskDropdown">
                        <li>
                            <a class="dropdown-item <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>"
                                href="/to-do-list/index.php">
                                <i class="fas fa-list-ul"></i> To-Do
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item <?php echo basename($_SERVER['PHP_SELF']) == 'completed.php' ? 'active' : ''; ?>"
                                href="/to-do-list/app/completed.php">
                                <i class="fas fa-check-circle"></i> Completed
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Logout -->
                <li class="nav-item">
                    <a class="nav-link text-white" href="#" onclick="confirmLogout(event)">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<script>
    function confirmLogout(event) {
        event.preventDefault();
        if (confirm("Are you sure you want to logout?")) {
            window.location.href = "/to-do-list/auth/logout.php";
        }
    }
</script>