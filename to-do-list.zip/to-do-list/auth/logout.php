<?php
session_start();

// Hapus semua data sesi
session_unset();
session_destroy();

// Redirect ke halaman login dengan pesan sukses
header("Location: ../loginform.php?logout=success");
exit();
