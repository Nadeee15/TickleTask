<?php
session_start();
require '../db_conn.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil input dari formulir
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Validasi input kosong
    if (empty($username) || empty($password)) {
        header("Location: ../loginform.php?error=Please fill in all fields");
        exit();
    }

    try {
        // Cek apakah username ada di database
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            // Simpan data user ke session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];

            // Redirect ke halaman utama (index.php)
            header("Location: ../index.php");
            exit();
        } else {
            // Login gagal
            header("Location: ../loginform.php?error=Invalid username or password");
            exit();
        }
    } catch (PDOException $e) {
        // Redirect dengan pesan error jika terjadi masalah database
        header("Location: ../loginform.php?error=Database error: " . urlencode($e->getMessage()));
        exit();
    }
} else {
    // Jika tidak melalui POST, redirect ke halaman login
    header("Location: ../loginform.php");
    exit();
}
?>