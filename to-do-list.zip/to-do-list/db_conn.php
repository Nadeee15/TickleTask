<?php
// Database connection settings
$host = "localhost";         // Host database
$username = "root";          // Username database
$password = "";              // Password database
$database = "to_do_list";    // Nama database

try {
    // Establish the PDO connection
    $conn = new PDO(
        "mysql:host=$host;dbname=$database;charset=utf8mb4",
        $username,
        $password
    );

    // Set PDO attributes for better error handling and security
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Enable exception handling
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);         // Disable emulation of prepared statements

    // Optional: Verify if the database connection is successful
    if ($conn) {
        error_log("Database connection established successfully to '$database'.", 0);
    }
} catch (PDOException $e) {
    // Log the error for debugging purposes
    error_log("Database Connection Error: " . $e->getMessage(), 0);

    // Display a user-friendly error message
    echo "<h1>Database Connection Error</h1>";
    echo "<p>We're currently experiencing an issue connecting to the database. Please try again later or contact support.</p>";

    // Stop script execution
    exit();
}

// Function to check connection status (optional for debugging)
function checkDatabaseConnection($conn, $database)
{
    try {
        $stmt = $conn->query("SELECT DATABASE()");
        $dbSelected = $stmt ? $stmt->fetchColumn() : null;

        if (!$dbSelected || $dbSelected !== $database) {
            throw new PDOException("Database '$database' not found or inaccessible.");
        }

        return true;
    } catch (PDOException $e) {
        error_log("Database Check Error: " . $e->getMessage(), 0);
        return false;
    }
}

// Check if database is accessible (can be removed in production)
if (!checkDatabaseConnection($conn, $database)) {
    die("Database check failed. Please contact support.");
}
?>