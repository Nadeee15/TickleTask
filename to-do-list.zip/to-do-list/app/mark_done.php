<?php
require '../db_conn.php';
session_start();

// Pastikan pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/loginform.php");
    exit();
}

// Validasi input task_id
if (isset($_POST['task_id']) && is_numeric($_POST['task_id'])) {
    $task_id = (int) $_POST['task_id'];
    $user_id = $_SESSION['user_id'];

    try {
        // Update status tugas menjadi "Done"
        $query = "UPDATE tasks SET status = 'Done' WHERE id = :task_id AND user_id = :user_id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':task_id', $task_id, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            // Redirect kembali ke halaman utama
            header("Location: ../index.php");
            exit();
        } else {
            echo "Failed to update the task.";
        }
    } catch (PDOException $e) {
        error_log("Error updating task: " . $e->getMessage());
        echo "An error occurred. Please try again later.";
    }
} else {
    echo "Invalid task ID.";
}
?>