<?php
if (isset($_POST['id']) && isset($_POST['title']) && isset($_POST['due_date'])) {
    require '../db_conn.php';

    $id = $_POST['id'];
    $title = $_POST['title'];
    $due_date = $_POST['due_date']; // Ambil tanggal tenggat baru

    if (!empty($title)) {
        // Update data tugas di database
        $stmt = $conn->prepare("UPDATE todos SET title = ?, due_date = ? WHERE id = ?");
        $stmt->execute([$title, $due_date, $id]);

        header("Location: ../index.php");
    } else {
        header("Location: ../index.php?mess=error");
    }
}
?>