<?php
require '../db_conn.php';
session_start();

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    die("Unauthorized access!");
}

// Ambil data dari formulir
$task_name = $_POST['task_name'] ?? '';
$due_date = $_POST['due_date'] ?? null;
$user_id = $_SESSION['user_id'];

// Validasi data
if (empty($task_name)) {
    die("Task name is required!");
}

if (empty($due_date)) {
    die("Due date and time are required!");
}

try {
    // Query untuk menyisipkan data ke tabel
    $stmt = $conn->prepare("INSERT INTO tasks (task_name, due_date, user_id) VALUES (:task_name, :due_date, :user_id)");
    $stmt->bindParam(':task_name', $task_name);
    $stmt->bindParam(':due_date', $due_date); // Format datetime-local langsung sesuai dengan tipe DATETIME
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    // Redirect kembali ke halaman utama setelah berhasil menambahkan tugas
    header("Location: ../index.php");
} catch (PDOException $e) {
    die("Error adding task: " . $e->getMessage());
}
