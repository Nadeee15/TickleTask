<?php
require 'db_conn.php';
session_start();

// Redirect jika belum login
if (!isset($_SESSION['username'], $_SESSION['user_id'])) {
    header("Location: auth/loginform.php");
    exit();
}

// Ambil nama pengguna dengan sanitasi
$username = htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8');

// Ambil daftar tugas dari database
try {
    $user_id = $_SESSION['user_id'];
    $query = "SELECT id, task_name, status, due_date, created_at, updated_at 
              FROM tasks 
              WHERE user_id = :user_id 
              ORDER BY due_date ASC";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching tasks: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TICKLE TASK</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        main {
            flex: 1;
        }

        footer {
            background: linear-gradient(to right, #357abd, #4a90e2);
            color: white;
            text-align: center;
            padding: 10px 0;
        }

        footer small {
            color: #ced4da;
        }
    </style>
</head>

<body>
    <!-- Include Navbar -->
    <?php include 'navbar.php'; ?>

    <main class="container py-4">
        <!-- Pesan Notifikasi -->
        <?php if (isset($_SESSION['message'])): ?>
            <div
                class="alert alert-<?php echo htmlspecialchars($_SESSION['msg_type'], ENT_QUOTES, 'UTF-8'); ?> text-center">
                <?php echo htmlspecialchars($_SESSION['message'], ENT_QUOTES, 'UTF-8'); ?>
            </div>
            <?php unset($_SESSION['message'], $_SESSION['msg_type']); ?>
        <?php endif; ?>

        <div class="text-center mb-4">
            <h1 class="text-primary">Welcome, <?php echo $username; ?>!</h1>
            <p class="text-muted">Manage your tasks efficiently with your personal Tickle Task.</p>
        </div>

        <!-- Daftar Tugas -->
        <div>
            <h3>To-Do Tasks</h3>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Task</th>
                            <th>Status</th>
                            <th>Due Date</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($tasks)): ?>
                            <?php foreach ($tasks as $task): ?>
                                <?php
                                $task_name = htmlspecialchars($task['task_name'], ENT_QUOTES, 'UTF-8');
                                $status = htmlspecialchars($task['status'], ENT_QUOTES, 'UTF-8');
                                $due_date = htmlspecialchars($task['due_date'], ENT_QUOTES, 'UTF-8');
                                $created_at = htmlspecialchars($task['created_at'], ENT_QUOTES, 'UTF-8');
                                $updated_at = htmlspecialchars($task['updated_at'], ENT_QUOTES, 'UTF-8');
                                ?>
                                <tr>
                                    <td><?php echo $task_name; ?></td>
                                    <td>
                                        <span class="badge <?php echo $status === 'Done' ? 'bg-success' : 'bg-warning'; ?>">
                                            <?php echo $status; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $due_date; ?></td>
                                    <td><?php echo $created_at; ?></td>
                                    <td><?php echo $updated_at; ?></td>
                                    <td>
                                        <?php if ($status !== 'Done'): ?>
                                            <form action="app/mark_done.php" method="POST" style="display:inline;">
                                                <input type="hidden" name="task_id"
                                                    value="<?php echo htmlspecialchars($task['id'], ENT_QUOTES, 'UTF-8'); ?>">
                                                <button type="submit" class="btn btn-success btn-sm">Mark as Done</button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-success">Completed</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">No tasks available. Add some tasks to get started!</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Formulir untuk Menambahkan Tugas Baru -->
        <div class="mt-4">
            <h3>Add New Task</h3>
            <form action="app/add.php" method="POST">
                <div class="mb-3">
                    <label for="task_name" class="form-label">Task Name</label>
                    <input type="text" class="form-control" id="task_name" name="task_name" required>
                </div>
                <div class="mb-3">
                    <label for="due_date" class="form-label">Due Date and Time</label>
                    <input type="datetime-local" class="form-control" id="due_date" name="due_date" required>
                </div>

                <button type="submit" class="btn btn-primary">Add Task</button>
            </form>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Tickle Task Website. All rights reserved.</p>
        <small>Tickle Task with by Kelompok 6.</small>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
</body>

</html>